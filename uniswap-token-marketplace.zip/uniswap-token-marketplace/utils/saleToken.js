export const ETH = "Eth";
export const COIN_1 = "Tether USD";
export const COIN_2 = "BNB";
export const COIN_3 = "USD Coin";
export const COIN_4 = "stETH";
export const COIN_5 = "TRON";
export const COIN_6 = "Matic Token";
export const COIN_7 = "SHIBA INU";
export const COIN_8 = "Uniswap";
export const DEFAULT_VALUE = "Select a token";
//
